let gameBoxImgs = document.querySelectorAll(".fc-24-mini img");
let gameBoxs = document.querySelectorAll(".fc-24-mini");
let leftSideImg = document.querySelector(".fc-24 img");

for (let i = 0; i < gameBoxs.length; i++) {
  gameBoxs[i].onclick = changePicture;
}
// every 4 seconds all boxs styles set to default value, animation and backgroundColor will pass to the next box
let i = 1;
let myInterval = setInterval(() => {
  gameBoxs.forEach((box) => {
    box.style.backgroundColor = "transparent";
  });
  let s = gameBoxs[i].childNodes[1].getAttribute("src");
  s = spliceString(s, -9, 9);
  s = `${s}.jpg`;
  leftSideImg.setAttribute("src", s);
  setBackgroundForMiniGamePic();
  gameBoxs[i].style.backgroundColor = "#202020";
  i = (i + 1) % gameBoxs.length;
}, 4000);
/* in this func at the begining we recieve a img's srcs of boxs
 and we compare the leftSide img src to current src,
  if they were equal we set a new element for the box to show us the animation */
let element = document.createElement("animation");
function setBackgroundForMiniGamePic() {
  gameBoxs.forEach((box) => {
    let boxSrc = box.childNodes[1].getAttribute("src");
    boxSrc = spliceString(boxSrc, -9, 9);
    boxSrc = `${boxSrc}.jpg`;
    if (leftSideImg.getAttribute("src") == boxSrc) {
      box.style.backgroundColor = "#202020";
      element.style.position = "absolute";
      element.style.left = "0";
      element.style.top = "0";
      element.style.bottom = "0";
      element.style.width = "0";
      element.style.backgroundColor = "rgba(0,0,0,0.2)";
      element.style.animation = "mini-game 4s ease-in-out infinite";
      box.appendChild(element);
    }
  });
}

setBackgroundForMiniGamePic();

//onclick func for boxes, set the leftsideImgSrc to currnet src
function changePicture() {
  let child = this.childNodes[1];
  let src = child.getAttribute("src");
  src = spliceString(src, -9, 9);
  leftSideImg.setAttribute("src", `${src}.jpg`);
  gameBoxs.forEach((e) => {
    if (leftSideImg.getAttribute("src") == `${src}.jpg`) {
      element.style.animation = "none";
      setBackgroundForMiniGamePic();

      e.style.backgroundColor = "transparent";
      this.style.backgroundColor = "#202020";
    }
  });
}

// splice fucntion for strings
function spliceString(str, start, deleteCount, add) {
  // Calculate the proper starting index
  if (start < 0) {
    start = str.length + start;
    if (start < 0) {
      start = 0;
    }
  }
  // Construct the new string
  return str.slice(0, start) + (add || "") + str.slice(start + deleteCount);
}